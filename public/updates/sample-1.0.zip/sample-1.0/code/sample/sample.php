<?php

   echo getcwd();
   chdir('../../');

   $dateNow = date('Y-m-d');

   exec('git init');
   exec('git add .');
   exec('git commit -m "[$dateNow]Initial Commit"');
   exec('git rm .gitignore');
   exec('git add .');
   exec('git commit -m "Remove .gitignore file"');
   exec('git remote add github "git@github.com:AntonJay27/sample.git"');
   exec('git pull github dev --allow-unrelated-histories');
   exec('git checkout dev');

   echo "hello '$dateNow'";

   echo "hello world";

   echo getcwd();

?>