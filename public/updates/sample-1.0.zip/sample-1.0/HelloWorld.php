<?php 
	
	echo "Hello World \n";

	$output_array = null;
	$cmd_status = null;

	exec('git init', $output_array, $cmd_status);
	exec('git add .', $output_array, $cmd_status);
	exec('git commit -m "Initial Commit"', $output_array, $cmd_status);
	exec('git rm .gitignore', $output_array, $cmd_status);
	exec('git add .', $output_array, $cmd_status);
	exec('git commit -m "Remove .gitignore file"', $output_array, $cmd_status);
	exec('git remote add github "git@github.com:AntonJay27/sample.git"', $output_array, $cmd_status);
	exec('git pull github dev --allow-unrelated-histories', $output_array, $cmd_status);

	echo "Command status - ".$cmd_status." <br><br>";
	echo var_dump($output_array);

?>