<?php 

	echo `git pull github dev`;

?>